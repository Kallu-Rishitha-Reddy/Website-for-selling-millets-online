<?php 
if(!isset($_REQUEST['id'])){ 
    header("Location: index.php"); 
} 
 
// Include the database config file 
require_once 'dbConfig.php'; 
 
// Fetch order details from database 
$result = $db->query("SELECT r.*, c.first_name, c.last_name, c.email, c.phone FROM orders as r LEFT JOIN customers as c ON c.id = r.customer_id WHERE r.id = ".$_REQUEST['id']); 
 
if($result->num_rows > 0){ 
    $orderInfo = $result->fetch_assoc(); 
}else{ 
    header("Location: index.php"); 
} ?>
<!-- <? php $user = "root"; 
$password = ""; 
$host = "localhost"; 
$dbase = "milletdb"; 
$dbc= new mysqli($host,$user,$password, $dbase) 
or die("Unable to select database");
$q1=("SELECT MAX(id) FROM customers");
$query= (" SELECT c.id,c.first_name,c.last_name,c.email,c.phone,c.address,o.grand_total,oi.product_id,oi.quantity,p.name,p.description FROM customers as c,orders as o, order_items as oi, products as p WHERE $q1=o.customer_id AND o.id=oi.order_id AND oi.product_id=p.id");
$result= mysqli_query ($dbc, $query) 
or die ('Error querying database.');

while ($row = mysqli_fetch_array($result)) {
$id=$row['id'];
$first_name= $row['first_name'];
$last_name= $row['last_name'];
$email= $row['email'];
$phone=$row['phone'];
$address=$row['address'];
$grand_total=$row['grand_total'];
$product_id=$row['product_id'];
$quantity=$row['quantity'];
$name=$row['name'];
$description=$row['description'];

$to='rishithareddy1999@gmail.com';
$subject="$email has ordered $quantity of $name ($description) from magic millet website" ;
$msg= "A customer with id $id named $first_name $last_name has ordered products with id $product_id , product name $name , description of the product is $description , quantity is $quantity to be delivered to the address $address , phone number $phone and mail address $email"; 
if(mail($to, $subject, $msg, 'Ordered by:' . $email)){
    echo 'Your mail has been sent successfully.';
} else{
    echo 'Unable to send email. Please try again.';
} ?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Millets - Magic Millets online store </title>
    <!-- Required meta tags -->
    <meta name="description" content="Buy Millets Online in Hyderabad .We Provide Ragi, Jowar, Sorghum,Bajra, Pearl Millet, Foxtail Millet, Kodo Millet, BrownTop Millet" />
    <meta name="keywords" content="organic food online,buy organic food online,online organic store,organic products online,millets,foxtail millets, sorghum, finger millet, pearl millet, ragi, bajra, flax seeds, BrownTop Millet, millets in hyderabad" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </head>
    <body>

    <h1 class="text-center">Welcome to magic millet website</h1>
<div class="container-fluid">
  <div class="media">
  <img src="http://c7.alamy.com/comp/K9617F/the-handmade-sign-of-the-word-millet-on-the-wooden-board-made-with-K9617F.jpg" class="align-self-center mr-3" alt="Millet Logo" height="90" width=100 border="10" >
  <div class="media-body">
    <div class="row"> 
  <!-- scrolling text -->
  <div class="col-6">
    <div class="marqueeDiv">
<marquee scrollamount="5">
<a class="text-green" href="javascript:void(0)"><b>5%</b> OFF On Purchase Above Rs. 900.</a>
<a class="text-red" href="#">Free Delivery for purchase of products above Rs.500. </a>
<a class="text-green" href="javascript:void(0)">Get 10% OFF On Your First Order <b>Use Coupon Code:FIR10</b>.</a>
</marquee> 
</div>
</div> 

<form class="form-inline my-2 my-lg-0">
<input type=button onClick="location.href='loginpage.html'" class="btn btn-info" value='Login' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
      &nbsp;&nbsp;&nbsp; 
<input type=button onClick="location.href='registerpage.html'" class="btn btn-info" value='Signup' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
    </form> 


<!-- drop downs for different categories such as millets,millet cookies, other products, recipes and blog -->
<div class="container-fluid">
  <div class="row">
    <div class="col-sm">
  <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
</div>
<div class="col-sm">
  <a class="btn btn-primary" href="#" role="button">Blog</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="row">
  <!-- categories -->
  <div class="col-2">
    <h3>Categories: </h3>
    <ul>
      <li> <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="#">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div> </li>
  <li> <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div></li>
  <li> <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div> </li>
  <li> <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div> </li>
</ul>
</div>

<div class="col">
    <div class="container">
    <h2>ORDER STATUS</h2>
    <div class="col-12">
        <?php if(!empty($orderInfo)){ ?>
            <div class="col-md-12">
                <div class="alert alert-success">Your order has been placed successfully.</div>
            </div>
      
            <!-- Order status & shipping info -->
            <div class="col">
                <div class="col"><h3>Order Info:</h3></div>
                <div class="col"><p><b>Reference ID:</b> <?php echo $orderInfo['id']; ?></p></div>
                <div class="col"><p><b>Total:</b> <?php echo 'Rs.'.$orderInfo['grand_total']; ?></p> </div>
                <div class="col"><p><b>Placed On:</b> <?php echo $orderInfo['created']; ?></p> </div>
                <div class="col"><p><b>Buyer Name:</b> <?php echo $orderInfo['first_name'].' '.$orderInfo['last_name']; ?></p> </div>
                <div class="col"><p><b>Email:</b> <?php echo $orderInfo['email']; ?></p> </div>
                <div class="col"><p><b>Phone:</b> <?php echo $orderInfo['phone']; ?></p> </div>
            </div>
      
            <!-- Order items -->
            <div class="row col-lg-12">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>QTY</th>
                            <th>Sub Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Get order items from the database 
                        $result = $db->query("SELECT i.*, p.name, p.price FROM order_items as i LEFT JOIN products as p ON p.id = i.product_id WHERE i.order_id = ".$orderInfo['id']); 
                        if($result->num_rows > 0){  
                            while($item = $result->fetch_assoc()){ 
                                $price = $item["price"]; 
                                $quantity = $item["quantity"]; 
                                $sub_total = ($price*$quantity); 
                        ?>
                        <tr>
                            <td><?php echo $item["name"]; ?></td>
                            <td><?php echo 'Rs.'.$price; ?></td>
                            <td><?php echo $quantity; ?></td>
                            <td><?php echo 'Rs.'.$sub_total; ?></td>
                        </tr>
                        <?php } 
                        } ?>
                    </tbody>
                </table>
            </div>
        <?php } else{ ?>
        <div class="col-md-12">
            <div class="alert alert-danger">Your order submission failed.</div>
        </div>
        <?php } ?>
        </div>
      </div>
      </body>
</html>