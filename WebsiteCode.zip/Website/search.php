<?php
    mysql_connect("localhost", "root", "") or die("Error connecting to database: ".mysql_error());
    /*
        localhost - it's location of the mysql server, usually localhost
        root - your username
        third is your password
         
        if connection fails it will stop loading the page and display an error
    */
     
    mysql_select_db("milletdb") or die(mysql_error());
    /* tutorial_search is the name of database we've created */
     
     
     
?>

<html lang="en">
  <head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="stylesheet" type="text/css" href="web/lib/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="web/lib/owlcarousel/css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="web/lib/owlcarousel/css/owl.theme.css">
    <link href="assets/owl.carousel.min.css" rel="stylesheet"/>
    <link href="assets/owl.theme.default.min.css" rel="stylesheet"/>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title> Millets - Magic Millets online store </title>
    <!-- Required meta tags -->
    <meta name="description" content="Buy Millets Online in Hyderabad .We Provide Ragi, Jowar, Sorghum,Bajra, Pearl Millet, Foxtail Millet, Kodo Millet, BrownTop Millet" />
    <meta name="keywords" content="organic food online,buy organic food online,online organic store,organic products online,millets,foxtail millets, sorghum, finger millet, pearl millet, ragi, bajra, flax seeds, BrownTop Millet, millets in hyderabad" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <style>
.rectangle {
  height: 200px;
  width: 800px;
  background-color: #ffcc00;
  padding: 20px;
  margin-top: 30px;
}
</style>

<!-- CSS code for search bar -->
<style>
* {box-sizing: border-box;}

body {
  margin: 15px;
  margin-left: 30px;
  margin-right: 30px;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  margin-top: 15px;
  margin-left: 70px;
  margin-right: 110px;
  margin-bottom: 15px;
  background-color: #ff8080;
}

.topnav .looking {
  background-color: #FFD700;
  margin-left: 40px;
  margin-right: 60px;
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 16px;
}

.topnav .search-container {
  float: right;
 }

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 9px;
  margin-right: 29px;
  background: #ADFF2F;
  font-size: 10px;
  height: 35px;
  width: 50px;
  border: none;
  cursor: pointer;
}

@media screen and (max-width: 1100px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 24px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
.force-scroll {
overflow-y: scroll;
height: 400px;
}
</style>


    <!-- CSS code for block containing health benefits of different types of millets -->
    <style type="text/css">
    .MultiCarousel { float: left; overflow: hidden; padding: 15px; width: 100%; position:relative; }
    .MultiCarousel .MultiCarousel-inner { transition: 1s ease all; float: left; }
        .MultiCarousel .MultiCarousel-inner .item { float: left;}
        .MultiCarousel .MultiCarousel-inner .item > div { text-align: center; padding:10px; margin:10px; background:#f1f1f1; color:#666;}
    .MultiCarousel .leftLst, .MultiCarousel .rightLst { position:absolute; border-radius:50%;top:calc(50% - 20px); }
    .MultiCarousel .leftLst { left:0; }
    .MultiCarousel .rightLst { right:0; }
    
        .MultiCarousel .leftLst.over, .MultiCarousel .rightLst.over { pointer-events: none; background:#ccc; }
        </style>  
  </head>

<body>
    <!-- heading -->
    <h1 class="text-center">Welcome to magic millet website</h1>
<div class="container-fluid">
  <div class="media">
  <img src="http://c7.alamy.com/comp/K9617F/the-handmade-sign-of-the-word-millet-on-the-wooden-board-made-with-K9617F.jpg" class="align-self-center mr-3" alt="Millet Logo" height="90" width=100 border="10" >
  <div class="media-body">
    <div class="row"> 
  <!-- scrolling text -->
  <div class="col-6">
    <div class="marqueeDiv">
<marquee scrollamount="5">
<a class="text-green" href="javascript:void(0)"><b>5%</b> OFF On Purchase Above Rs. 900.</a>
<a class="text-red" href="#">Free Delivery for purchase of products above Rs.500. </a>
<a class="text-green" href="javascript:void(0)">Get 10% OFF On Your First Order <b>Use Coupon Code:FIR10</b>.</a>
</marquee> 
</div>
</div> 

<form class="form-inline my-2 my-lg-0">
<input type=button onClick="location.href='loginpage.html'" class="btn btn-info" value='Login' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
      &nbsp;&nbsp;&nbsp; 
<input type=button onClick="location.href='registerpage.html'" class="btn btn-info" value='Signup' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
    </form> 


<!-- drop downs for different categories such as millets,millet cookies, other products, recipes and blog -->
<div class="container-fluid">
  <div class="row">
    <div class="col-sm">
  <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-success dropdown-toggle" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
</div>
<div class="col-sm">
  <a class="btn btn-primary" href="#" role="button">Blog</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<!-- code for search bar -->
 <div class="topnav">
  <a class="looking"> <b> I am looking for    </b> </a>
    <button type="button" class="btn btn-primary dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="height: 50px; width: 150px" >
    All categories
  </button>
  <div class="dropdown-menu dropdown-menu-right force-scroll" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
  <div class="search-container">
    <form action="search.php" method="GET">
      <input type="text" placeholder="Search for..." name="query">
      <button type="submit" value="Search"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div> 
<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search results</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body> -->
<?php
    $query = $_GET['query']; 
    // gets value sent over search form
     $i=1;
    $min_length = 1;
    // you can set minimum length of the query if you want
     
    if(strlen($query) >= $min_length)
    { // if query length is more or equal minimum length then
         
        $query = htmlspecialchars($query); 
        // changes characters used in html to their equivalents, for example: < to &gt;
         
        $query = mysql_real_escape_string($query);
        // makes sure nobody uses SQL injection
         
        $raw_results = mysql_query("SELECT * FROM search_engine
            WHERE (`pagecontent` LIKE '%".$query."%') OR (`pagecontent` LIKE '%".$query."%')") or die(mysql_error());
             
        // * means that it selects all fields, you can also write: `id`, `title`, `text`
        // articles is the name of our table
         
        // '%$query%' is what we're looking for, % means anything, for example if $query is Hello
        // it will match "hello", "Hello man", "gogohello", if you want exact match use `title`='$query'
        // or if you want to match just full word so "gogohello" is out use '% $query %' ...OR ... '$query %' ... OR ... '% $query'
         
        if(mysql_num_rows($raw_results) > 0)
        { // if one or more rows are returned do following
             
        	echo "<p><h3> Search Results for ".$query." are as follows: </h3> </p>"; ?>

        	<div class="table-responsive">
  				<table class="table">
  				<table class="table table-bordered">
				  <thead class="thead-light">
 				   <tr>
 				     <th scope="col"><b>Number</b></th>
 				     <th scope="col"><b>Item Name</b></th>
 				     <th scope="col"><b>Link</b></th>
				    </tr>
				  </thead>
            <?php while($results = mysql_fetch_array($raw_results))
            {
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop-->
            			$url = $results['pageurl']; ?>
 					 <tbody>
 					   <tr>
   					   <th scope="row"><?php echo "$i"; ?> </th>
     					 <td> <?php echo "<p>".$results['pagecontent']."</p>";?> </td>
     					 <td> <?php echo "<a href='$url'> <b> Click here </b> to open the page </a> ";?> </td>
   						 </tr>
 					 </tbody>
					<?php $i=$i+1;

                // posts results gotten from database(title and text) you can also show id ($results['id']) -->
            } ?>
            </table>
            </table>
            </div>
             
        <?php } 
         
       else
        { // if there is no matching rows do following
            echo "No results"; 
        }
    } 
         
    else{ // if query length is less than minimum 
        echo "Minimum length is ".$min_length; 
   		 }
	 ?>
</body>
</html>