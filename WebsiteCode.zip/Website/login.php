<form action="loginfile.php" method="post"> 
    User Name:<br> 
    <input type="email" name="email"><br><br> 
    Password:<br> 
    <input type="password" name="password"><br><br> 
    <input type="submit" name="submit" value="Login"> 
</form> 