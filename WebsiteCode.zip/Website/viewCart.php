<?php 
// Initialize shopping cart class 
include_once 'Cart.class.php'; 
$cart = new Cart; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Millets - Magic Millets online store </title>
    <!-- Required meta tags -->
    <meta name="description" content="Buy Millets Online in Hyderabad .We Provide Ragi, Jowar, Sorghum,Bajra, Pearl Millet, Foxtail Millet, Kodo Millet, BrownTop Millet" />
    <meta name="keywords" content="organic food online,buy organic food online,online organic store,organic products online,millets,foxtail millets, sorghum, finger millet, pearl millet, ragi, bajra, flax seeds, BrownTop Millet, millets in hyderabad" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Custom style -->
<link href="css/style.css" rel="stylesheet">

<!-- jQuery library -->
<script src="js/jquery.min.js"></script>

<script>
function updateCartItem(obj,id){
    $.get("cartAction.php", {action:"updateCartItem", id:id, qty:obj.value}, function(data){
        if(data == 'ok'){
            location.reload();
        }else{
            alert('Cart update failed, please try again.');
        }
    });
}
</script>

<style>
* {box-sizing: border-box;}

body {
  margin: 15px;
  margin-left: 30px;
  margin-right: 30px;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  margin-top: 15px;
  margin-left: 70px;
  margin-right: 110px;
  margin-bottom: 15px;
  background-color: #ff8080;
}

.topnav .looking {
  background-color: #FFD700;
  margin-left: 40px;
  margin-right: 60px;
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 15px;
}

.topnav .search-container {
  float: right;
 }

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 9px;
  margin-right: 29px;
  background: #ADFF2F;
  font-size: 10px;
  height: 35px;
  width: 50px;
  border: none;
  cursor: pointer;
}

@media screen and (max-width: 1100px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 24px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
.force-scroll {
overflow-y: scroll;
height: 400px;
}
</style>

  </head>
    <body>

    <h1 class="text-center">Welcome to magic millet website</h1>
<div class="container-fluid">
  <div class="media">
  <img src="http://c7.alamy.com/comp/K9617F/the-handmade-sign-of-the-word-millet-on-the-wooden-board-made-with-K9617F.jpg" class="align-self-center mr-3" alt="Millet Logo" height="90" width=100 border="10" >
  <div class="media-body">
    <div class="row"> 
  <!-- scrolling text -->
  <div class="col-6">
    <div class="marqueeDiv">
<marquee scrollamount="5">
<a class="text-green" href="javascript:void(0)"><b>5%</b> OFF On Purchase Above Rs. 900.</a>
<a class="text-red" href="#">Free Delivery for purchase of products above Rs.500. </a>
<a class="text-green" href="javascript:void(0)">Get 10% OFF On Your First Order <b>Use Coupon Code:FIR10</b>.</a>
</marquee> 
</div>
</div> 

<form class="form-inline my-2 my-lg-0">
<input type=button onClick="location.href='loginpage.html'" class="btn btn-info" value='Login' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
      &nbsp;&nbsp;&nbsp; 
<input type=button onClick="location.href='registerpage.html'" class="btn btn-info" value='Signup' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
    </form> 


<!-- drop downs for different categories such as millets,millet cookies, other products, recipes and blog -->
<div class="container-fluid">
  <div class="row">
    <div class="col-sm">
  <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
</div>
<div class="col-sm">
  <a class="btn btn-primary" href="#" role="button">Blog</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<!-- code for search bar -->
 <div class="topnav">
  <a class="looking"> <b> I am looking for    </b> </a>
    <button type="button" class="btn btn-primary dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="height: 50px; width: 150px" >
    All categories
  </button>
  <div class="dropdown-menu dropdown-menu-right force-scroll" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
  <div class="search-container">
    <form action="search.php" method="GET">
      <input type="text" placeholder="Search for..." name="query">
      <button type="submit" value="Search"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>

<div class="row">
  <!-- categories -->
  <div class="col-2">
    <h3>Categories: </h3>
    <ul>
      <li> <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="#">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div> </li>
  <li> <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div></li>
  <li> <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div> </li>
  <li> <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div> </li>
</ul>
</div>

<div class="col">

<div class="container">
    <h2>SHOPPING CART</h2>
    <div class="row">
        <div class="cart">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th width="45%">Product</th>
                                <th width="20%">Price</th>
                                <th width="15%">Quantity</th>
                                <th class="text-right" width="20%">Total</th>
                                <th width="10%">Remove </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if($cart->total_items() > 0){ 
                                // Get cart items from session 
                                $cartItems = $cart->contents(); 
                                foreach($cartItems as $item){ 
                            ?>
                            <tr>
                                <td><?php echo $item["name"]; ?></td>
                                <td><?php echo 'Rs'.$item["price"].' INR'; ?></td>
                                <td><input class="form-control" type="number" value="<?php echo $item["qty"]; ?>" onchange="updateCartItem(this, '<?php echo $item["rowid"]; ?>')"/></td>
                                <td class="text-right"><?php echo 'Rs.'.$item["subtotal"].' INR'; ?></td>
                                <td class="text-right"><button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')?window.location.href='cartAction.php?action=removeCartItem&id=<?php echo $item["rowid"]; ?>':false;"><i class="itrash"></i> </button> </td>
                            </tr>
                            <?php } }else{ ?>
                            <tr><td colspan="5"><p>Your cart is empty</p></td>
                            <?php } ?>
                            <?php if($cart->total_items() > 0){ ?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><strong>Cart Total</strong></td>
                                <td class="text-right"><strong><?php echo 'Rs.'.$cart->total().' INR'; ?></strong></td>
                                <td></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col mb-2">
                <div class="row">
                    <div class="col-sm-12  col-md-6">
                        <a href="index.php" class="btn btn-block btn-primary">Continue Shopping</a>
                    </div>
                    <div class="col-sm-12 col-md-6 text-right">
                        <?php if($cart->total_items() > 0){ ?>
                        <a href="checkout.php" class="btn btn-lg btn-block btn-success">Checkout</a>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>