<?php 
if(isset($_POST['submit'])){ 
    $dbHost = "localhost";       //Location Of Database usually its localhost 
    $dbUser = "root";            //Database User Name 
    $dbPass = "";                //Database Password 
    $dbDatabase = "milletdb";    //Database Name 
     
    $db = mysqli_connect($dbHost,$dbUser,$dbPass)or die("Error connecting to database."); 
    //Connect to the database 
    mysqli_select_db($db,$dbDatabase)or die("Couldn't select the database."); 
    $email = mysqli_real_escape_string($db,$_POST['email']); 
    $password = mysqli_real_escape_string($db,$_POST['password']); 
    $sql = mysqli_query($db,"SELECT * FROM register WHERE email='$email' AND  password='$password' LIMIT 1"); 
    if(mysqli_num_rows($sql) == 1){ 
        $row = mysqli_fetch_array($sql); 
        session_start(); 
        $_SESSION['email'] = $row['email']; 
        $_SESSION['logged'] = TRUE; 
        echo "<script> alert('You have logged in successfully') </script>";// Modify to go to the page you would like 
        header("Location: milletswebsite.html");
        exit; 
    }else{ 
        echo "<script> alert('Email or Password is incorrect')</script>";  
        exit;
    } 
     
}
?> 

<?php 
session_start(); 
if(!$_SESSION['logged']){ 
    header("Location: signregister.php"); 
    exit; 
} 
echo 'Welcome, '.$_SESSION['email']; 
?> 