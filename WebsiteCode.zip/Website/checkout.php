<?php 
// Include the database config file 
require_once 'dbConfig.php'; 
 
// Initialize shopping cart class 
include_once 'Cart.class.php'; 
$cart = new Cart; 
 
// If the cart is empty, redirect to the products page 
if($cart->total_items() <= 0){ 
    header("Location: index.php"); 
} 
 
// Get posted data from session 
$postData = !empty($_SESSION['postData'])?$_SESSION['postData']:array(); 
unset($_SESSION['postData']); 
 
// Get status message from session 
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:''; 
if(!empty($sessData['status']['msg'])){ 
    $statusMsg = $sessData['status']['msg']; 
    $statusMsgType = $sessData['status']['type']; 
    unset($_SESSION['sessData']['status']); 
} 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Millets - Millets Online store in Hyderabad </title>
    <!-- Required meta tags -->
    <meta name="description" content="Buy Millets Online in Hyderabad .We Provide Ragi, Jowar, Sorghum,Bajra, Pearl Millet, Foxtail Millet, Kodo Millet, BrownTop Millet" />
    <meta name="keywords" content="organic food online,buy organic food online,online organic store,organic products online,millets,foxtail millets, sorghum, finger millet, pearl millet, ragi, bajra, flax seeds, BrownTop Millet, millets in hyderabad" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta charset="utf-8">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Custom style -->
<link href="css/style.css" rel="stylesheet">
<!-- CSS code for search bar -->
<style>
* {box-sizing: border-box;}

.topnav {
  margin-top: 15px;
  margin-left: 70px;
  margin-right: 110px;
  margin-bottom: 15px;
  background-color: #ff8080;
}

.topnav .looking {
  background-color: #FFD700;
  margin-left: 40px;
  margin-right: 60px;
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 15px;
}

.topnav .search-container {
  float: right;
 }

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 9px;
  margin-right: 29px;
  background: #ADFF2F;
  font-size: 10px;
  height: 35px;
  width: 50px;
  border: none;
  cursor: pointer;
}

@media screen and (max-width: 1100px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 24px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
.force-scroll {
overflow-y: scroll;
height: 400px;
}
</style>

</head>
<body>

    <h1 class="text-center">Welcome to online millet website</h1>
<div class="container-fluid">
  <div class="media">
  <img src="http://c7.alamy.com/comp/K9617F/the-handmade-sign-of-the-word-millet-on-the-wooden-board-made-with-K9617F.jpg" class="align-self-center mr-3" alt="Millet Logo" height="90" width=100 border="10" >
  <div class="media-body">
    <div class="row"> 
  <!-- scrolling text -->
  <div class="col-6">
    <div class="marqueeDiv">
<marquee scrollamount="5">
<a class="text-green" href="javascript:void(0)"><b>5%</b> OFF On Purchase Above Rs. 900.</a>
<a class="text-red" href="#">Free Delivery for purchase of products above Rs.500. </a>
<a class="text-green" href="javascript:void(0)">Get 10% OFF On Your First Order <b>Use Coupon Code:FIR10</b>.</a>
</marquee> 
</div>
</div> 

<form class="form-inline my-2 my-lg-0">
<input type=button onClick="location.href='loginpage.html'" class="btn btn-info" value='Login' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
      &nbsp;&nbsp;&nbsp; 
<input type=button onClick="location.href='registerpage.html'" class="btn btn-info" value='Signup' style="backgroundcolor:black;color:white;width:120px;
height:40px;">
    </form> 


<!-- drop downs for different categories such as millets,millet cookies, other products, recipes and blog -->
<div class="container-fluid">
  <div class="row">
    <div class="col-sm">
  <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div>
</div>
<div class="col-sm">
  <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
</div>
<div class="col-sm">
  <a class="btn btn-primary" href="#" role="button">Blog</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<!-- code for search bar -->
 <div class="topnav">
  <a class="looking"> <b> I am looking for    </b> </a>
    <button type="button" class="btn btn-primary dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="height: 50px; width: 150px" >
    All categories
  </button>
  <div class="dropdown-menu dropdown-menu-right force-scroll" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="index.php">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div>
  <div class="search-container">
    <form action="search.php" method="GET">
      <input type="text" placeholder="Search for..." name="query">
      <button type="submit" value="Search"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>

<div class="row">
  <!-- categories -->
  <div class="col-2">
    <h3>Categories: </h3>
    <ul>
      <li> <button type="button" class="btn btn-danger dropdown-toggle" id="dropdownMenuMillets" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millets
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMillets">
    <a class="dropdown-item" href="#">Andu Korralu</a>
    <a class="dropdown-item" href="#">Foxtail Millets</a>
    <a class="dropdown-item" href="#">Ragi- Finger Millets</a>
    <a class="dropdown-item" href="#">Jowar- Sorghum</a>
    <a class="dropdown-item" href="#">Bajra- Pearl Millets</a>
    <a class="dropdown-item" href="#">Proso Millets</a>
    <a class="dropdown-item" href="#">Kodo Millets</a>
    <a class="dropdown-item" href="#">Barnyard Millets</a>
    <a class="dropdown-item" href="#">Little Millets</a>
  </div> </li>
  <li> <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" id="dropdownMenuMilletCookies" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Millet Cookies
  </button>
  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuMilletCookies">
    <a class="dropdown-item" href="#">Cookies made from Millets</a>
  </div></li>
  <li> <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Other Products
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Multigrain</a>
    <a class="dropdown-item" href="#">Wheat</a>
    <a class="dropdown-item" href="#">Besan</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makhana</a>
    <a class="dropdown-item" href="#">Barley</a>
    <a class="dropdown-item" href="#">Soya</a>
    <a class="dropdown-item" href="#">Quinoa</a>
    <a class="dropdown-item" href="#">Sabja Seeds</a>
    <a class="dropdown-item" href="#">Makkai Corn</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
    <a class="dropdown-item" href="#">Chia Seeds</a>
  </div> </li>
  <li> <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Recipes
  </button>
  <div class="dropdown-menu dropdown-menu-right">
    <a class="dropdown-item" href="#">Navratri- Recipe</a>
    <a class="dropdown-item" href="#">Jowar- Jonnalu</a>
    <a class="dropdown-item" href="#">Bajra- Sajjalu</a>
    <a class="dropdown-item" href="#">Ragi</a>
    <a class="dropdown-item" href="#">Kodo Millet</a>
    <a class="dropdown-item" href="#">Little Millet</a>
    <a class="dropdown-item" href="#">Foxtail Millet</a>
    <a class="dropdown-item" href="#">Barnyard Millet</a>
    <a class="dropdown-item" href="#">Flax Seeds</a>
    <a class="dropdown-item" href="#">Phool Makahana</a>
    <a class="dropdown-item" href="#">Brown Rice</a>
  </div> </li>
</ul>
</div>

<div class="col">

<div class="container">
    <h2>CHECKOUT</h2>
    <div class="col-12">
        <div class="checkout">
            <div class="row">
                <?php if(!empty($statusMsg) && ($statusMsgType == 'success')){ ?>
                <div class="col-md-12">
                    <div class="alert alert-success"><?php echo $statusMsg; ?></div>
                </div> 
                <?php } ?>
                <?php if(!empty($statusMsg) && ($statusMsgType == 'error')){ ?>
                <div class="col-md-12">
                    <div class="alert alert-danger"><?php echo $statusMsg; ?></div>
                </div>
                <?php } ?>
        
                <div class="col-md-4 order-md-2 mb-4">
                    <h4 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-muted">Your Cart</span>
                        <span class="badge badge-secondary badge-pill"><?php echo $cart->total_items(); ?></span>
                    </h4>
                    <ul class="list-group mb-3">
                        <?php 
                        if($cart->total_items() > 0){ 
                            //get cart items from session 
                            $cartItems = $cart->contents(); 
                            foreach($cartItems as $item){ 
                        ?>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0"><?php echo $item["name"]; ?></h6>
                                <small class="text-muted"><?php echo 'Rs.'.$item["price"]; ?>(<?php echo $item["qty"]; ?>)</small>
                            </div>
                            <span class="text-muted"><?php echo 'Rs.'.$item["subtotal"]; ?></span>
                        </li>
                        <?php } } ?>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Total (INR)</span>
                            <strong><?php echo 'Rs.'.$cart->total(); ?></strong>
                        </li>
                    </ul>
                    <a href="index.php" class="btn btn-block btn-info">Add Items</a>
                </div>
                <div class="col-md-8 order-md-1">
                    <h4 class="mb-3">Contact Details</h4>
                    <form method="post" action="cartAction.php">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="first_name">First Name</label>
                                <input type="text" class="form-control" name="first_name" value="<?php echo !empty($postData['first_name'])?$postData['first_name']:''; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="last_name">Last Name</label>
                                <input type="text" class="form-control" name="last_name" value="<?php echo !empty($postData['last_name'])?$postData['last_name']:''; ?>" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo !empty($postData['email'])?$postData['email']:''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" name="phone" value="<?php echo !empty($postData['phone'])?$postData['phone']:''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="last_name">Address</label>
                            <input type="text" class="form-control" name="address" value="<?php echo !empty($postData['address'])?$postData['address']:''; ?>" required>
                        </div>
                        <input type="hidden" name="action" value="placeOrder"/>
                        <input class="btn btn-success btn-lg btn-block" type="submit" name="checkoutSubmit" value="Place Order">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</body>
</html>